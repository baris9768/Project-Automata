#!/bin/sh
docker build -t rvmt .
